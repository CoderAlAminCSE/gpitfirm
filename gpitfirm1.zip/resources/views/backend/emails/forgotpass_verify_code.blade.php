<!DOCTYPE html>
<html>
<body>
    <p>The verification code is: {{ $details['code'] }}</p>
</body>
</html>
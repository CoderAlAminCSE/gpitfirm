  <section class="ptb-100">
      <div class="container">
          <div class="row">
              <div class="col-lg-12">
                {!! refundPageContent('content') !!}
              </div>
          </div>
      </div>
  </section>
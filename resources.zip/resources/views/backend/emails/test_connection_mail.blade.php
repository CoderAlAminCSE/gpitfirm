Test Connection Email

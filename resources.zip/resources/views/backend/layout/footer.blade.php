<div id="kt_app_footer" class="app-footer">
  <!--begin::Footer container-->
  <div class="app-container container-fluid d-flex flex-column flex-md-row flex-md-stack py-3">
    <!--begin::Copyright-->
    <div class="text-dark order-1 order-md-1 ml-auto"> <!-- Add ml-auto class here -->
      <span class="text-muted fw-semibold me-1">2023&copy;</span>
      <a href="https://gpitfirm.com/" target="_blank" class="text-gray-800 text-hover-primary">GPITFIRM</a>
    </div>
  </div>
  <!--end::Footer container-->
</div>

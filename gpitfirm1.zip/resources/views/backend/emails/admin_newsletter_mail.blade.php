<p>{!! $details['message'] !!}</p>
